<?php
namespace KiwiCommerce\Testimonials\Model\Resource\Testimonials;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection {
    /**
     * Define model & resource model
     */
    protected function _construct(){
        $this->_init('KiwiCommerce\Testimonials\Model\Testimonials', 'KiwiCommerce\Testimonials\Model\Resource\Testimonials' );
    }
}
