<?php

namespace KiwiCommerce\Testimonials\Model\Resource;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Testimonials extends AbstractDb {
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('kiwicommerce_testimonials', 'id');
    }
}
