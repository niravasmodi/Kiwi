<?php

namespace KiwiCommerce\Testimonials\Model;

use KiwiCommerce\Testimonials\Api\TestimonialsRepositoryInterface;
use KiwiCommerce\Testimonials\Model\Resource\Testimonials\CollectionFactory;

class TestimonialsRepository implements TestimonialsRepositoryInterface
{
    private $collectionFactory;

    public function __construct(CollectionFactory $collectionFactory)
    {
        $this->collectionFactory = $collectionFactory;
    }

    public function getList()
    {
        return $this->collectionFactory->create()->getItems();
    }
}
