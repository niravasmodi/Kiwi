<?php
/**
 * @category KiwiCommerce
 * @package KiwiCommerce_Testimonials
 * @author Nirav Modi <nirav.as.modi@gmail.com / nirav.as.modi@gmail.com >
 * @copyright Copyright (c) 2018 KiwiCommerce, Ltd (http://www.kiwicommerce.com)
 * @license http://opensource.org/licenses/afl-3.0.php Academic Free License (AFL 3.0)
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'KiwiCommerce_Testimonials',
    __DIR__
);
