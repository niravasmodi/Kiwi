<?php

namespace KiwiCommerce\Testimonials\Block;

use Magento\Framework\View\Element\Template;
use KiwiCommerce\Testimonials\Model\TestimonialsFactory;

class TestimonialsList extends Template {
   /**
    * @var \KiwiCommerce\Testimonials\Model\TestimonialsFactory
    */
   protected $_testimonialsFactory;

   /**
    * @param Template\Context $context
    * @param TestimonialsFactory $testimonialsFactory
    * @param array $data
    */
   public function __construct(
      Template\Context $context,
      TestimonialsFactory $testimonialsFactory,
      array $data = []  ) {
        $this->_testimonialsFactory = $testimonialsFactory;
        parent::__construct($context, $data);
   }

   /**
     * Set testimonials collection
     */
    protected  function _construct() {
        parent::_construct();
        $collection = $this->_testimonialsFactory->create()
        ->getCollection()->addFilter('status', 1)->setOrder('id', 'DESC');
        //$_products->addAttributeToFilter('status', 1); // Without using the operator
        $this->setCollection($collection);
    }

   /**
     * @return $this
     */
    protected function _prepareLayout() {
        parent::_prepareLayout();
        /** @var \Magento\Theme\Block\Html\Pager */
        $pager = $this->getLayout()->createBlock(
           'Magento\Theme\Block\Html\Pager','testimonials.testimonials.list.pager'
        );
        $pager->setLimit(5)->setShowAmounts(false)->setCollection($this->getCollection());
        $this->setChild('pager', $pager);
        $this->getCollection()->load();
        return $this;
    }

   /**
     * @return string
     */
    public function getPagerHtml() {
        return $this->getChildHtml('pager');
    }
}
