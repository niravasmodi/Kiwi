<?php

namespace KiwiCommerce\Testimonials\Block\Adminhtml;

use Magento\Backend\Block\Widget\Grid\Container;

class Testimonials extends Container{
   /**
     * Constructor
     *
     * @return void
     */
   protected function _construct(){
        $this->_controller = 'adminhtml_testimonials';
        $this->_blockGroup = 'KiwiCommerce_Testimonials';
        $this->_headerText = __('Manage Testimonials');
        $this->_addButtonLabel = __('Add Testimonials');
        parent::_construct();
    }
}
