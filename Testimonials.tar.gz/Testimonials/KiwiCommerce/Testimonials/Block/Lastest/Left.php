<?php

namespace KiwiCommerce\Testimonials\Block\Lastest;

use KiwiCommerce\Testimonials\Block\Lastest;
use KiwiCommerce\Testimonials\Model\System\Config\LastestTestimonials\Position;

class Left extends Lastest
{
   public function _construct()
   {
      $position = $this->_dataHelper->getLastestTestimonialsBlockPosition();
      // Check this position is applied or not
      if ($position == Position::LEFT) {
         $this->setTemplate('KiwiCommerce_Testimonials::lastest.phtml');
      }
   }
}
