<?php

namespace KiwiCommerce\Testimonials\Block\Lastest;

use KiwiCommerce\Testimonials\Block\Lastest;
use KiwiCommerce\Testimonials\Model\System\Config\LastestTestimonials\Position;

class Right extends Lastest
{
   public function _construct()
   {
      $position = $this->_dataHelper->getLastestTestimonialsBlockPosition();
      // Check this position is applied or not
      if ($position == Position::RIGHT) {
         $this->setTemplate('KiwiCommerce_Testimonials::lastest.phtml');
      }
   }
}
