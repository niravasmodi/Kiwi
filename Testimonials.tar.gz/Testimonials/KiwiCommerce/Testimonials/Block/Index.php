<?php
namespace KiwiCommerce\Testimonials\Block;
class Index extends \Magento\Framework\View\Element\Template
{

}
