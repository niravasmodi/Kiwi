<?php

namespace KiwiCommerce\Testimonials\Block;

use Magento\Framework\View\Element\Template;
use KiwiCommerce\Testimonials\Helper\Data;
use KiwiCommerce\Testimonials\Model\TestimonialsFactory;
use KiwiCommerce\Testimonials\Model\System\Config\Status;

class Lastest extends Template
{
   /**
    * @var \KiwiCommerce\Testimonials\Helper\Data
    */
   protected $_dataHelper;

   /**
    * @var \KiwiCommerce\Testimonials\Model\TestimonialsFactory
    */
   protected $_testimonialsFactory;

   /**
    * @param Template\Context $context
    * @param Data $dataHelper
    * @param TestimonialsFactory $testimonialsFactory
    */
   public function __construct(
      Template\Context $context,
      Data $dataHelper,
      TestimonialsFactory $testimonialsFactory
   ) {
      $this->_dataHelper = $dataHelper;
      $this->_testimonialsFactory = $testimonialsFactory;
      parent::__construct($context);
   }

   /**
    * Get five latest testimonials
    *
    * @return \KiwiCommerce\Testimonials\Model\Resource\Testimonials\Collection
    */
   public function getLatestTestimonials()
   {
      // Get testimonials collection
      $collection = $this->_testimonialsFactory->create()->getCollection();
      $collection->addFieldToFilter(
         'status',
         ['eq' => Status::ENABLED]
      );
      $collection->getSelect()
         ->order('id DESC')
         ->limit(5);

      return $collection;
   }
}
