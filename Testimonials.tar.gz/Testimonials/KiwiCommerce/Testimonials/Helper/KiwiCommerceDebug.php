<?php
namespace KiwiCommerce\Testimonials\Helper;

use Monolog\Logger;
use Magento\Framework\Logger\Handler\Base;

class KiwiCommerceDebug extends Base{
    /**
     * @var string
     */
    protected $fileName = '/var/log/kiwicommerce_debug.log';

    /**
     * @var int
     */
    protected $loggerType = Logger::DEBUG;
}
