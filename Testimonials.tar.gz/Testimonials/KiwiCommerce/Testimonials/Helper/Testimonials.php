<?php
namespace KiwiCommerce\Testimonials\Helper;

use \Magento\Framework\App\Helper\Context;
use \Magento\Store\Model\StoreManagerInterface;
use \Magento\Framework\App\State;
use \KiwiCommerce\Testimonials\Model\TestimonialsFactory;
use \Symfony\Component\Console\Input\Input;
use \Psr\Log\LoggerInterface;
use \Magento\Framework\Event\ManagerInterface;

class Testimonials extends \Magento\Framework\App\Helper\AbstractHelper {
    const KEY_TITLE = 'testimonials-title';
    const KEY_SUMMARY = 'testimonials-summary';
    const KEY_DESC = 'testimonials-description';

    protected $storeManager;
    protected $state;
    protected $testimonialsFactory;
    protected $data;
    protected $testimonialsId;
    protected $logger;
    protected $eventManager;
    // $eventManager


    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
        State $state,
        TestimonialsFactory $testimonialsFactory,
        LoggerInterface $logger,
        ManagerInterface $eventManager) {
            $this->storeManager = $storeManager;
            $this->state = $state;
            $this->logger = $logger;
            $this->eventManager = $eventManager;
            $this->testimonialsFactory = $testimonialsFactory;

        parent::__construct($context);
    }

    public function setData(Input $input){
        $this->data = $input;
        return $this;
    }

    public function execute() {
        $this->state->setAreaCode('frontend');
        $testimonials = $this->testimonialsFactory->create();
        $testimonials->setTitle($this->data->getOption(self::KEY_TITLE))
            ->setSummary($this->data->getOption(self::KEY_SUMMARY))
            ->setDescription($this->data->getOption(self::KEY_DESC));
        $testimonials->save();
        $this->logger->debug('DI: '.$testimonials->getTitle());
        // EventCode...
        $this->eventManager->dispatch('kiwicommerce_testimonials_save_after', ['object' => $testimonials]);
        $this->testimonialsId = $testimonials->getId();

        // if($this->data->getOption(self::KEY_SENDEMAIL)) {
        //     $testimonials->sendNewAccountEmail();
        // }
    }

    public function getTestimonialsId(){
        return (int)$this->testimonialsId;
    }
}
