var config = {
    'map': {
        '*': {
            'mage/validation': 'KiwiCommerce_Testimonials/js/validation' 
        }
    }

     /*,
    config: {
        mixins: {
            'KiwiCommerce_Testimonials/js/validation': {
                'KiwiCommerce_Testimonials/js/validation-mixin': true
            }
        }
    }*/
};
