<?php

namespace KiwiCommerce\Testimonials\Api;

interface TestimonialsRepositoryInterface {
    /**
     * @return \KiwiCommerce\Testimonials\Api\Data\TestimonialsInterface[]
     */
    public function getList();
}
