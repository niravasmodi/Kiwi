<?php

namespace KiwiCommerce\Testimonials\Api\Data;

interface TestimonialsInterface {
    /**
     * @return string
     */
    public function getCompanyName();

    /**
     * @return string|null
     */
    public function getName();
    
    /**
     * @return string|null
     */
    public function getMessage();

    /**
     * @return string|null
     */
    public function getPost();

    /**
     * @return string|null
     */
    public function getProfilePic();

    /**
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * @return string|null
     */
    public function getUpdatedAt();
}
