<?php

namespace KiwiCommerce\Testimonials\Controller\Adminhtml;

 use Magento\Backend\App\Action;
 use Magento\Backend\App\Action\Context;
 use Magento\Framework\Registry;
 use Magento\Framework\View\Result\PageFactory;
 use KiwiCommerce\Testimonials\Model\TestimonialsFactory;

//class Testimonials extends Action
abstract class Testimonials extends Action   //\Magento\Backend\App\Action

{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * Result page factory
     *
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;

    /**
     * Testimonials model factory
     *
     * @var \KiwiCommerce\Testimonials\Model\TestimonialsFactory
     */
    protected $_testimonialsFactory;

    /**
     * @param Context $context
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param TestimonialsFactory $testimonialsFactory
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        TestimonialsFactory $testimonialsFactory
    ) {
       parent::__construct($context);
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->_testimonialsFactory = $testimonialsFactory;
    }


    /**
     * Initiate action
     *
     * @return this
     */
    /*
    protected function _initAction()
    {
    	$this->_view->loadLayout();
    	$this->_setActiveMenu('KiwiCommerce_Testimonials::items')->_addBreadcrumb(__('Testimonials'), __('Testimonials'));
    	return $this;
    }
    */
    /**
     * Testimonials access rights checking
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('KiwiCommerce_Testimonials::manage_testimonials');
    }
}
