<?php

namespace KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

use KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

class Index extends Testimonials{
    /**
     * @return void
     */
   public function execute(){
      if ($this->getRequest()->getQuery('ajax')) {
            $this->_forward('grid');
            return;
        }
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_resultPageFactory->create();
        $resultPage->setActiveMenu('KiwiCommerce_Testimonials::main_menu');
        $resultPage->getConfig()->getTitle()->prepend(__('Simple Testimonials'));

        return $resultPage;
   }
}
