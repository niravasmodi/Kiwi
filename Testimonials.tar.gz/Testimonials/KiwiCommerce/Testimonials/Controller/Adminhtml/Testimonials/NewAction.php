<?php

namespace KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

use KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

class NewAction extends Testimonials
{
   /**
     * Create new testimonials action
     *
     * @return void
     */
   public function execute()
   {
      $this->_forward('edit');
   }
}
