<?php

namespace KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

use KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

class Grid extends Testimonials
{
   /**
     * @return void
     */
   public function execute()
   {
      return $this->_resultPageFactory->create();
   }
}
