<?php

namespace KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

use KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

class Delete extends Testimonials
{
   /**
    * @return void
    */
   public function execute()
   {
      $testimonialsId = (int) $this->getRequest()->getParam('id');

      if ($testimonialsId) {
         /** @var $testimonialsModel \Mageworld\Testimonials\Model\Testimonials */
         $testimonialsModel = $this->_testimonialsFactory->create();
         $testimonialsModel->load($testimonialsId);

         // Check this testimonials exists or not
         if (!$testimonialsModel->getId()) {
            $this->messageManager->addError(__('This testimonials no longer exists.'));
         } else {
               try {
                  // Delete testimonials
                  $testimonialsModel->delete();
                  $this->messageManager->addSuccess(__('The testimonials has been deleted.'));

                  // Redirect to grid page
                  $this->_redirect('*/*/');
                  return;
               } catch (\Exception $e) {
                   $this->messageManager->addError($e->getMessage());
                   $this->_redirect('*/*/edit', ['id' => $testimonialsModel->getId()]);
               }
            }
      }
   }
}
