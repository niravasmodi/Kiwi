<?php

namespace KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

use KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

class MassDelete extends Testimonials
{
   /**
    * @return void
    */
   public function execute()
   {
      // Get IDs of the selected testimonials
      $testimonialsIds = $this->getRequest()->getParam('testimonials');

        foreach ($testimonialsIds as $testimonialsId) {
            try {
               /** @var $testimonialsModel \Mageworld\Testimonials\Model\Testimonials */
                $testimonialsModel = $this->_testimonialsFactory->create();
                $testimonialsModel->load($testimonialsId)->delete();
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            }
        }

        if (count($testimonialsIds)) {
            $this->messageManager->addSuccess(
                __('A total of %1 record(s) were deleted.', count($testimonialsIds))
            );
        }

        $this->_redirect('*/*/index');
   }
}
