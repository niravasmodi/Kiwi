<?php

namespace KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

use KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

class Save extends Testimonials
{
   /**
     * @return void
     */
   public function execute()
   {
      $isPost = $this->getRequest()->getPost();

      if ($isPost) {
         $testimonialsModel = $this->_testimonialsFactory->create();
         $testimonialsId = $this->getRequest()->getParam('id');

         if ($testimonialsId) {
            $testimonialsModel->load($testimonialsId);
         }
         $formData = $this->getRequest()->getParam('testimonials');
         $testimonialsModel->setData($formData);

         try {
            // Save testimonials
            $testimonialsModel->save();

            // Display success message
            $this->messageManager->addSuccess(__('The testimonials has been saved.'));

            // Check if 'Save and Continue'
            if ($this->getRequest()->getParam('back')) {
               $this->_redirect('*/*/edit', ['id' => $testimonialsModel->getId(), '_current' => true]);
               return;
            }

            // Go to grid page
            $this->_redirect('*/*/');
            return;
         } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
         }

         $this->_getSession()->setFormData($formData);
         $this->_redirect('*/*/edit', ['id' => $testimonialsId]);
      }
   }
}
