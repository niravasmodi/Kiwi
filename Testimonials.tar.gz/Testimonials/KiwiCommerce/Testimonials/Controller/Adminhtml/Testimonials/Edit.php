<?php

namespace KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

use KiwiCommerce\Testimonials\Controller\Adminhtml\Testimonials;

class Edit extends Testimonials
{
   /**
     * @return void
     */
   public function execute()
   {
      $testimonialsId = $this->getRequest()->getParam('id');
        /** @var \KiwiCommerce\Testimonials\Model\Testimonials $model */
        $model = $this->_testimonialsFactory->create();

        if ($testimonialsId) {
            $model->load($testimonialsId);
            if (!$model->getId()) {
                $this->messageManager->addError(__('This testimonials no longer exists.'));
                $this->_redirect('*/*/');
                return;
            }
        }

        // Restore previously entered form data from session
        $data = $this->_session->getTestimonialsData(true);
        if (!empty($data)) {
            $model->setData($data);
        }
        $this->_coreRegistry->register('testimonials_testimonials', $model);

        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_resultPageFactory->create();
        $resultPage->setActiveMenu('KiwiCommerce_Testimonials::main_menu');
        $resultPage->getConfig()->getTitle()->prepend(__('Testimonials'));

        return $resultPage;
   }
}
