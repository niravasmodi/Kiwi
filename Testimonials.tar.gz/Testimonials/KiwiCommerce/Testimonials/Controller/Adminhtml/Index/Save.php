<?php

namespace KiwiCommerce\Testimonials\Controller\Adminhtml\Index;

use KiwiCommerce\Testimonials\Model\TestimonialsFactory;

class Save extends \Magento\Backend\App\Action {
    private $testimonialsFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        TestimonialsFactory $testimonialsFactory
    ) {
        $this->testimonialsFactory = $testimonialsFactory;
        parent::__construct($context);
    }

    public function execute(){
        $this->testimonialsFactory->create()
            ->setData($this->getRequest()->getPostValue()['general'])->save();
        return $this->resultRedirectFactory->create()->setPath('testimonials/index/index');
    }
}
