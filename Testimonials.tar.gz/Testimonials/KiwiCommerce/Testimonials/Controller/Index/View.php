<?php

namespace KiwiCommerce\Testimonials\Controller\Index;

use KiwiCommerce\Testimonials\Controller\Testimonials;

class View extends Testimonials
{
    public function execute()
    {
	// Get testimonials ID
        $testimonialsId = $this->getRequest()->getParam('id');
	// Get testimonials data
        $testimonials = $this->_testimonialsFactory->create()->load($testimonialsId);
	// Save testimonials data into the registry
        $this->_objectManager->get('Magento\Framework\Registry')
            ->register('testimonialsData', $testimonials);

        $pageFactory = $this->_pageFactory->create();

        // Add title
        $pageFactory->getConfig()->getTitle()->set($testimonials->getTitle());

        // Add breadcrumb
        /** @var \Magento\Theme\Block\Html\Breadcrumbs */
        $breadcrumbs = $pageFactory->getLayout()->getBlock('breadcrumbs');
        $breadcrumbs->addCrumb('home',
            [
                'label' => __('Home'),
                'title' => __('Home'),
                'link' => $this->_url->getUrl('')
            ]
        );
        $breadcrumbs->addCrumb('testimonials',
            [
                'label' => __('Testimonials'),
                'title' => __('Testimonials'),
                'link' => $this->_url->getUrl('testimonials')
            ]
        );
        $breadcrumbs->addCrumb('testimonials',
            [
                'label' => $testimonials->getTitle(),
                'title' => $testimonials->getTitle()
            ]
        );

        return $pageFactory;
    }
}
