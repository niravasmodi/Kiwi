<?php

namespace KiwiCommerce\Testimonials\Controller\Index;

use KiwiCommerce\Testimonials\Controller\Testimonials;

class Index extends Testimonials{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_pageFactory;

    protected $_dataHelper;

    protected $_url;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $_pageFactory,
        \KiwiCommerce\Testimonials\Helper\Data $_dataHelper,
        \KiwiCommerce\Testimonials\Model\TestimonialsFactory $testimonialsFactory,
        \Magento\Backend\Model\UrlInterface $_url
    ) {
        parent::__construct(
            $context,
            $_pageFactory,
            $_dataHelper,
            $testimonialsFactory
        );
        $this->_dataHelper = $_dataHelper;
        $this->_url = $_url;
    }
    
    public function execute(){
        $pageFactory = $this->_pageFactory->create();
        $pageFactory->getConfig()->getTitle()->set($this->_dataHelper->getHeadTitle());
        //Add breadcrumb
        $breadcrumbs = $pageFactory->getLayout()->getBlock('breadcrumbs');
        $breadcrumbs->addCrumb('home', ['label'=>__('Home'), 'title'=>__('Home'), 'link'=>$this->_url->getUrl('')]);
        $breadcrumbs->addCrumb('testimonials', ['label'=>__('Testimonials'), 'title'=>__('Testimonials')]);

        return $pageFactory;
    }
}
