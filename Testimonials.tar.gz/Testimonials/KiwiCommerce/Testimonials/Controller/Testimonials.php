<?php
namespace KiwiCommerce\Testimonials\Controller;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\View\Result\PageFactory;
use KiwiCommerce\Testimonials\Helper\Data;
use KiwiCommerce\Testimonials\Model\TestimonialsFactory;

abstract class Testimonials extends Action
{
    protected $_pageFactory;
    protected $_dataHelper;
    protected $_testimonialsFactory;

    /*
        The order is always based on the parameters of the original constructor, extra parameters go in the end
    */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \KiwiCommerce\Testimonials\Helper\Data $helper,
        \KiwiCommerce\Testimonials\Model\TestimonialsFactory $testimonialsFactory
    ){
        $this->_pageFactory = $pageFactory;
        $this->_dataHelper = $helper;
        $this->_testimonialsFactory = $testimonialsFactory;
        parent::__construct($context);
    }

    public function dispatch(RequestInterface $request) {
        if($this->_dataHelper->isEnabledInFrontend()) {
            $result = parent::dispatch($request);
            return $result;
        }
        else {
            $this->_forward('noroute');
        }
    }
}
